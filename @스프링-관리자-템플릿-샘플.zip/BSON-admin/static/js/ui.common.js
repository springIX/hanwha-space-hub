var YT = YT || null, win;
if(typeof console=="undefined"){ console = { log : function(){}, info : function(){}, warn : function(){}, error : function(){} }; }

(function(global, ui){
  'use strict';

  win = { h : 0, w : 0, wrap : null, scrolltop : 0, scrollheight : 0, scrollleft : 0, scrolldir : "", size : {header:0, footer:0, fixhead:0, fixheadtop:0, foottop:0} };
  var _evt = {
    winclick : function(e){
      var target = e.target.nodeName==="A"||e.target.nodeName==="BUTTON" ? e.target : e.currentTarget, $target = $.$(target), $relele, uipop;
      uipop = target.getAttribute("data-uipop");
      document.focusEl = target;

      if($target.is("[data-anchor]")) anchorani.call(target, e);
      if(uipop){
        $relele = url2el(target, null);
        if(uipop==0 || uipop==1){
          if(!$relele) $relele = $target.closest('[data-uipopset]');
          if($relele.length==0) $relele = null;
          if(!$relele && !window.parent.length) self.close();
          if($relele && uipop==0) $relele.uipop("close");
          if($relele && uipop==1) $relele.uipop("open");
        }else if(uipop!="" && uipop!=undefined){
          var url = target.getAttribute("href") || target.getAttribute("data-url");
          var _data = $.extend([], $target.data("uipop"));
          _data.unshift(url);
          $target.uipop({winpop:_data});
        }
        e && e.preventDefault();
      }
    },
    winresize : function(e, first){
      var _oldWidth = win.w, _layout = _page.layout;
      win.h = window.innerHeight;
      win.w = window.innerWidth;
      win.scrollheight = document.body.scrollHeight;
      win.size.header = _layout.header.$obj?_layout.header.$obj.innerHeight():0;
      if(!first && _oldWidth!=win.w) swipeset.sizecheck(); //swipe tab
      if(_layout.header.$obj) _layout.pageresize.call(_layout);
    },
    winscroll : function(e, first){
      if(first && first==-1) win.scrolltop -= 1;
      var curscrolltop = _page.$win.scrollTop(), curscrollleft = _page.$win.scrollLeft(), _dir, _layout = _page.layout;
      _dir = win.scrolltop>curscrolltop ? "up" : "down";
      if(win.scrolldir!=_dir) _page.$body.replaceClass("(up|down)",_dir);
      win.scrolltop = curscrolltop;
      win.scrollleft = curscrollleft;
      win.scrolldir = _dir;
      if(_layout.header.$obj) _layout.pagesc.call(_layout);
    },
    doc : function($wrap){
      $wrap.findFilter("span[data-placeholder='true'], input[data-placeholder='true'], textarea[data-placeholder='true']").off('focus.placeholder blur.placeholder change.placeholder').on('focus.placeholder', function() { $.$(this).removeClass("placeholder"); }).on('blur.placeholder change.placeholder', function() {
        if(this.value||(this.nodeName=="SPAN"&&this.innerHTML.replace(/ */,"")!="")) $.$(this).removeClass("placeholder"); else $.$(this).addClass("placeholder");
      }).trigger('change.placeholder');
      var selectPlaceholder = function(){
        var $this = $.$(this);
        var isEqual = ($.trim($this.find("option").eq(this.selectedIndex).text()).toLowerCase()==$.trim(this.getAttribute("data-placeholder")).toLowerCase());
        if(isEqual) $this.addClass("placeholder");
        else $this.removeClass("placeholder");
      };
      $wrap.findFilter("select[data-placeholder]").each(selectPlaceholder).off("change.placeholder").on("change.placeholder", selectPlaceholder).trigger("change.placeholder");
      $wrap.findFilter("input[data-comma]").off("blur.comma focus.comma").on("focus.comma", function(){ var isRead=$.$(this).prop("readonly"); if(!isRead) this.value=this.value.replace(/[^\d\.]/g, ''); }).on("blur.comma", function(){ this.value=this.value.replace(/[^\d\.]/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',') }).trigger("blur.comma");
      $wrap.off("change.fakefile", "input[type='file']").on("change.fakefile", "input[type='file']", function(){
        this.parentNode.setAttribute("data-filename", this.value);
      }).trigger('change.fakefile');
    },
    init : function($wrap, isReInit){
      var _ = this;
      if(!$wrap) $wrap = _page.$body;
      _.doc($wrap); //form event
      if(!isReInit){
        _page.$body.off("click.linkHandler").off("click.linkHandler", "a, button, area").on("click.linkHandler", "a, button, area", _.winclick).off("focus.appFocus blur.appFocus", "input:not([type='checkbox']):not([type='radio']),select,textarea");
        _page.$win.off("resize.layoutsc orientationChange.layoutsc").on("resize.layoutsc orientationChange.layoutsc", _.winresize).trigger("resize.layoutsc", true).off("scroll.layoutsc").on("scroll.layoutsc", _.winscroll).trigger("scroll.layoutsc");
        setTimeout(function(){ _page.$win.trigger("resize.layoutsc", true).trigger("scroll.layoutsc", true); }, 500);
      }else{
        _page.$win.trigger("resize.layoutsc", true).trigger("scroll.layoutsc", true);
      }
    }
  };
  var _page = {
    $win : $(window), $html : null, $body : null, wintitle : "", msg : {selected : "선택됨"},
    reInit : function($wrap){
      var _ = _page, isReInit = true;
      if(!_.$body) return;
      if(!$wrap) $wrap = _.$body, isReInit = false;
      if(win.h==0) win.h = _page.$win.height(), win.w = _page.$win.width(), win.scrollheight = document.body.scrollHeight;

      //_player.init($wrap); //youtube 플레이어 셋
      $wrap.findFilter('[data-calendar]').uicalendar(); // 캘린더
      $wrap.findFilter('[data-tab]').tab();
      $wrap.findFilter('[data-dropdown]').dropdown();

      $wrap.findFilter(".cont-variable").each(function(){
        var _ = this, $this = $.$(_), max = this.getAttribute("data-max") || 3;
        _.temp = $this.children().eq(0).clone();
        if(!_.temp.length) return;
        $this.off("click.variable", "[data-btn]").on("click.variable", "[data-btn]", function(){
          var _$p = $.$(this).parent().parent();
          if(this.getAttribute("data-btn")=="add"){
            if($this.children().length>=max) return;
            _$p.after(_.temp.clone());
          }else{
            _$p.remove();
          }
        });
      });

      setTimeout(function(){ $wrap.findFilter('dl[data-accordion], table[data-accordion], div[data-accordion], ul[data-accordion]').accordion(); }, 200);
      _evt.init($wrap, isReInit);
    },
    layout : {
      header : { $obj : null },
      container : { $obj : null },
      pagesc : function(e){
        var _layout = _page.layout;
      },
      pageresize : function(e){
        var _layout = _page.layout;
      },
      popup : {
        resize : function($wrap){
          if(!$wrap.length || window.parent.length) return false;
          var size = {
            doc : {w : $wrap.first().innerWidth(), h : $wrap.first().innerHeight()},
            max : {w : Math.min(screen.width, document.body.offsetWidth), h : Math.min(screen.height, document.body.offsetHeight)}
          };
          window.resizeBy(size.doc.w-size.max.w, size.doc.h-size.max.h);
        }
      },
      init : function(){
        var _ = this;
        win.wrap = $("body > .wrap").get(0) || null;
        _.header.$obj = $(".header");
        if(!_.header.$obj.length) _.header.$obj = null;
        _.container.$obj = $(".container");
        if(!_.container.$obj.length) _.container.$obj = null;
        win.size.header = _.header.$obj?_.header.$obj.innerHeight():0;

        $(".aside .navi .toggle").each(function(){
          $.$(this).parent().click(function(e){
            $.$(this).parent().toggleClass("active");
            e.preventDefault();
          });
        });

        setTimeout(function(){ _.popup.resize($("div[data-resizewrap]")); }, 200); //팝업리사이즈
      }
    },
    init : function(){
      var _ = this;
      _.layout.init();
      _.reInit();
    }
  };

  $(document).ready(function(){
    _page.$html= $("html");
    _page.$body = $("body");
    _page.init();
  });

  //public
  ui.reInit = _page.reInit;
  ui.loading = {
    $obj : null, objhtml : ['<div class="loading visible">','<div class="loading wrap-in visible">','<div class="ui-spinner"><div class="spinner-blade"></div><div class="spinner-blade"></div><div class="spinner-blade"></div><div class="spinner-blade"></div><div class="spinner-blade"></div><div class="spinner-blade"></div><div class="spinner-blade"></div><div class="spinner-blade"></div><div class="spinner-txt">Loading...</div></div></div>'],
    enable : function($wrap){
      if($wrap){
        var _wrap = $wrap.get(0);
        if(!_wrap.$loading){
          _wrap.$loading = $(this.objhtml[1]+this.objhtml[2]);
          $wrap.prepend(_wrap.$loading);
        }else{
          _wrap.$loading.addClass("visible");
        }
      }else{
        if(!this.$obj){
          this.$obj = $(this.objhtml[0]+this.objhtml[2]);
          $("body").prepend(this.$obj);
        }else{ this.$obj.addClass("visible"); }
      }
    },
    disable : function($wrap){
      if($wrap){
        var _wrap = $wrap.get(0);
        _wrap.$loading&&_wrap.$loading.removeClass("visible");
      }else{
        this.$obj&&this.$obj.removeClass("visible");
      }
    }
  };

})(this, this.ui = this.ui || {});