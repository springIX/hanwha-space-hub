/* **********************************************************************
	nameSpace 생성
********************************************************************** */
;(function(window, $){
	'use strict';

	var global = "$utils", nameSpace = "ADMIN.utils", nameSpaceRoot = null;

	function createNameSpace(identifier, module){
		var win = window, name = identifier.split('.'), p, i = 0;

		if(!!identifier){
			for (i = 0; i < name.length; i += 1){
				if(!win[ name[ i ] ]){
					if(i === 0){
						win[ name[ i ] ] = {};
						nameSpaceRoot = win[ name[ i ] ];
					} else {
						win[ name[ i ] ] = {};
					}
				}
				win = win[ name[ i ] ];
			}
		}
		if(!!module){
			for (p in module){
				if(!win[ p ]){
					win[ p ] = module[ p ];
				} else {
					throw new Error("module already exists! >> " + p);
				}
			}
		}
		return win;
	}

	if(!!window[ global ]){
		throw new Error("already exists global!> " + global);
	}

	window[ global ] = createNameSpace(nameSpace, {
		namespace : function(identifier, module){
			return createNameSpace(identifier, module);
		}
	});
})(window, jQuery);

/* **********************************************************************
	전역변수
********************************************************************** */
var admin;

/* **********************************************************************
	ADMIN.common
	* ui 초기화
	* @memberof ADMIN.common
********************************************************************** */
;(function(window, $) {
	'use strict';
	admin = $utils.namespace('ADMIN.common', {
		/* ---------------------------------------------------------------------------
			레이아웃 : 네비게이션(전체메뉴/GNB)
		--------------------------------------------------------------------------- */
		uiNav : function(){
			$('#navMenu').find('li.active').addClass('open');
		},

		/* ---------------------------------------------------------------------------
			레이아웃 : 스크롤이동에 따른 UI컨트롤
		--------------------------------------------------------------------------- */
		uiFixed : function(){
		},

		/* ---------------------------------------------------------------------------
			공통UI : 테이블정보
		--------------------------------------------------------------------------- */
		setTableCaption : function(){
			$("table").each(function() {
				var $this = $(this),
					thText = "",
					count = 0,
					thLength = 0,
					thList = null;

				if( !$this.hasClass("ui-caption-on") ) {
					if($this.find('> thead').length>0) thList = $this.find("> thead > tr:first-child > th");
					else thList = $this.find("> tbody > tr > th");

					thLength = thList.length;

					thList.each(function() {
						var $this = $(this);
						count += 1;
						thText += $this.text() + ( thLength === count ? "": ", " );
					});

					$this.find('> caption').eq(0).text($this.find('> caption').eq(0).text()+"("+thText+")");
				}
			});
		},

		/* ---------------------------------------------------------------------------
			폼객체  : 디자인변형 : file
		--------------------------------------------------------------------------- */
		setFormDesign : function(){
			$(document).off('change.formFile','.label-file1 input[type="file"]').on('change.formFile','.label-file1 input[type="file"]',function(ev){
				$(this).parents('.label-file1 label').next('span').remove();
				if($(this).val()) $(this).parents('.label-file1 label').after($('<span>').text($(this).val()));
			});

			$(document).on('click', '.label-file1[data-max] .btn button', function(e){
				var fileArea = $(this).parents('.label-file1').eq(0);
				var fileMax = fileArea.attr('data-max');
				if($(e.target).attr('data-btn')=="add"){
					if(fileArea.find('> div').length < fileMax){
						var newField = fileArea.find('>div').eq(0).clone();
						newField.find('label').next('span').remove();
						//newField.find('input[type="file"]').attr('name', fileArea.attr('data-filename') + (fileArea.find('>div').length+1));
						fileArea.append(newField);
					}else{
						alert(fileMax + '개까치 첨부 가능합니다.');
					}
				}else{
					if(fileArea.find('>div').length < 2){

					}else{
						$(e.target).parents('.label-file1 > div').remove();
					}
				}
			});
		},

		/* ---------------------------------------------------------------------------
			폼객체  : 디자인변형 : datepicker
		--------------------------------------------------------------------------- */
		setDatepicker : function(){
			$(".input-date").each(function(){
				if(!$(this).attr("id")){
					var $that= $(this);
					var $buttonText = $that.find(">.hd").text();
					if($that.find("input.text").length>1){
						$(this).find("input.text").eq(0).datepicker({
							dateFormat : "yy.mm.dd",
							showOn: "button",
							showOtherMonths : true,
							showMonthAfterYear : true,
							showButtonPanel: true,
							changeYear : true,
							changeMonth : true,
							maxDate : "+1y",
							dayNamesMin : ['일','월','화','수','목','금','토'],
							monthNamesShort : ['01','02','03','04','05','06','07','08','09','10','11','12'],
							buttonText : $buttonText+" 검색시작일 달력으로 선택<span></span>",
							onClose: function( selectedDate ) {
								$that.find("input.text").eq(1).datepicker( "option", "minDate", selectedDate );
								$(this).removeClass("blank");
							}
						});
						$(this).find("input.text").eq(1).datepicker({
							dateFormat : "yy.mm.dd",
							showOn: "button",
							showOtherMonths : true,
							showMonthAfterYear : true,
							showButtonPanel: true,
							changeYear : true,
							changeMonth : true,
							maxDate : "+1y",
							dayNamesMin : ['일','월','화','수','목','금','토'],
							monthNamesShort : ['01','02','03','04','05','06','07','08','09','10','11','12'],
							buttonText : $buttonText+"검색종료일 달력으로 선택<span></span>",
							onClose: function( selectedDate ) {
								$that.find("input.text").eq(0).datepicker( "option", "maxDate", selectedDate );
								$(this).removeClass("blank");
							}
						});
					}else{
						$that.find("input.text").eq(0).datepicker({
							dateFormat : "yy.mm.dd",
							showOn: "button",
							showOtherMonths : true,
							showMonthAfterYear : true,
							showButtonPanel: true,
							changeYear : true,
							changeMonth : true,
							yearRange : "1900 : 2026",
							maxDate : "+1y",
							dayNamesMin : ['일','월','화','수','목','금','토'],
							monthNamesShort : ['01','02','03','04','05','06','07','08','09','10','11','12'],
							buttonText : $buttonText+" 달력으로 선택<span></span>"
						});
					}
				}
			});
		},

		/* --------------------------------------------------
			공통기능 : 스크롤이동
		-------------------------------------------------- */
		targetScroll : function(obj, flag){
			//객체위치 + 여분여백
			var target_position = obj.offset().top - 35;
			var target_focus = true;

			if(flag!=null) target_focus = flag;
		},

		/* ---------------------------------------------------------------------------
			init reload : 동적생성 컨텐츠중 재호출이 필요한 함수
		--------------------------------------------------------------------------- */
		initReload : function(){
		},

		initReset : function(){
		},

		/* ---------------------------------------------------------------------------
			init : onload
		--------------------------------------------------------------------------- */
		init: function() {
			admin.uiNav();
			admin.setTableCaption();
			admin.setDatepicker();
			admin.setFormDesign();
		}
	});
	$(document).ready(admin.init);
})(window, jQuery);

/* **********************************************************************
	PUBLISH PLUGIN : togglecon
	* 토글형컨텐츠 : 탭, 아코디언 등
********************************************************************** */
(function(window, $){
	'use strict';
	var short = '$plugin';
	window[short] = window['$utils'].namespace('PROJECT.plugins', {
		togglecon : function(element, options){
			var version = "1.0.0",
				pluginName = "publish.togglecon",
				methods = {},
				el = element,
				length = el.size(),
				toggles = [],
				togglecons,
				defaults = {
					toggle_type : 'toggle',
					aria_flag : true,
					selector : '',
					selector_group : true,
					selector_btn : '[data-toggle="btn"]',
					selector_con : '[data-toggle="content"]',
					selector_close : '[data-toggle="btn-close"]',
					event_flag : false,
					btn_event : 'click',
					btn_flag : false,
					doc_event : false,
					class_active : 'active',
					auto_scroll : false,
					load_animation : false,
					txt_state : true,
					txt_state_open : '펼치기',
					txt_state_close : '접기',
					callback_before: null,
					callback_load : null,
					callback_after: null
				};

			if (length < 1) return;
			if (length > 1){
				el.each(function(i, tar){
					toggles.push(window[short].togglecon($(tar), options));
				});
				return toggles;
			}
			if (el.data(pluginName)) return;

			/* ---------------------------------------------------------------------------
				togglecon.init : 초기화
			--------------------------------------------------------------------------- */
			methods.init = function(){
				methods.initVars();
				methods.initEvent();
			};

			/* ---------------------------------------------------------------------------
				togglecon.initVars : 변수설정
			--------------------------------------------------------------------------- */
			methods.initVars = function(){
				el.options = $.extend({}, defaults, options);
				el.vars = {
					this_group : null,
					this_wrapper : null,
					this_btn : null,
					this_con : null,
					this_close : null
				};
			};

			/* ---------------------------------------------------------------------------
				togglecon.initEvent : 이벤트설정
			--------------------------------------------------------------------------- */
			methods.initEvent = function(){
				el.vars.this_wrapper = el;

				//콜백함수(before)
				if (typeof el.options.callback_before === 'function'){
					el.options.callback_before.call(el,el.vars);
				};

				if(el.options.btn_event=="focus"){
					$(document).off('click.togglecon1 mouseover.togglecon').on('click.togglecon1 mouseover.togglecon', el.options.selector+' '+el.options.selector_btn, function(e){
						el.vars.this_btn = $(this);

						if(el.options.selector_con=="#href"){
							e.preventDefault();
							el.vars.this_con = $($(this).attr("href"));
						}else{
							el.vars.this_con = $(this).parents(el.options.selector);
						}
						methods.conShow();
					});
				}else{
					$(document).off('click.togglecon2', el.options.selector+' '+el.options.selector_btn).on('click.togglecon2', el.options.selector+' '+el.options.selector_btn, function(e){
						if(!el.options.event_flag) e.preventDefault();

						el.vars.this_btn = $(this);

						if(el.options.selector_con=="#href"){
							el.vars.this_con = $($(this).attr("href"));
						}else{
							el.vars.this_con = $(this).parents(el.options.selector);
						}

						if(el.options.toggle_type=="form"){
							if($(this).val()=="Y") methods.conShow();
							else methods.conHide();
						}else{
							if (!el.vars.this_con.hasClass(el.options.class_active) || el.options.toggle_type=="tab") {
								methods.conShow();
							} else {
								methods.conHide();
							}
						}
					});
				}

				//접근성개선
				if(el.options.aria_flag){
					if(el.options.toggle_type=='tab'){
						if(el.find('>ul').length) el.find('>ul').attr('role','tablist');
						else el.attr('role','tablist');
					}

					$(el.options.selector + ' ' + el.options.selector_btn).each(function(){
						var $el_element = $(this).parents(el.options.selector);
						var $el_element_btn = $(this), _href;

						if(el.options.toggle_type=='tab'){
							$el_element_btn.attr('role','tab');
							_href = $(this).attr('href');

							if($el_element.hasClass(el.options.class_active)){
								$el_element_btn.attr('aria-selected',true).attr('title','선택됨');
								if(!_href.match(/(\/|.+\..+)/)){
									$($(this).attr('href'))
										.attr('role','tabpanel')
										.attr('aria-expanded',true);
								}
							}else{
								$el_element_btn.attr('aria-selected',false).attr('title','');
								if(!_href.match(/(\/|.+\..+)/)){
									$($(this).attr('href'))
										.attr('role','tabpanel')
										.attr('aria-expanded',false);
								}
							}
						}

						if(el.options.toggle_type=='toggle'){
							if($el_element.hasClass(el.options.class_active)){
								$el_element_btn.attr('aria-expanded',true);
							}else{
								$el_element_btn.attr('aria-expanded',false);
							}
						}
					});
				}
			};

			/* ---------------------------------------------------------------------------
				togglecon.conShow : 열기
			--------------------------------------------------------------------------- */
			methods.conShow = function(){

				//그룹형일때 초기화
				if(el.options.selector_group){

					if(el.options.load_animation){
						el.vars.this_con.siblings().removeClass(el.options.class_active);
						el.vars.this_con.siblings().find(el.options.selector_con).slideUp(400, function(){
						});
					}
					else{
						el.vars.this_con.siblings().removeClass(el.options.class_active);
					}

					$(el.options.selector+' '+el.options.selector_btn).each(function(){
						if(el.options.toggle_type =="tab"){
							$(this).parents(el.options.selector).removeClass(el.options.class_active);
							if(el.options.selector_con=="#href") $($(this).attr('href')).removeClass(el.options.class_active);
							if(el.options.aria_flag){
								$(this).attr('aria-selected',false).attr('title','');
								if(el.options.selector_con=="#href") $($(this).attr('href')).attr('aria-expanded',false);
							}
						}

						if(el.options.toggle_type =="toggle"){
							if(el.options.btn_flag) $(this).removeClass(el.options.class_active);
							if(el.options.txt_state){
								if($(this).attr('title')) $(this).attr('title',$(this).attr('title').replace(el.options.txt_state_close,el.options.txt_state_open));
								if($(this).attr('aria-label')) $(this).attr('aria-label',$(this).attr('aria-label').replace(el.options.txt_state_close,el.options.txt_state_open));
								$(this).html($(this).html().replace(el.options.txt_state_close,el.options.txt_state_open));
							}
							if(el.options.aria_flag){
								$(this).attr('aria-expanded',false);
							}
						}
					});
				}

				//오픈클래스 적용 / aria 설정
				if(el.options.load_animation){
					el.vars.this_con.addClass(el.options.class_active);
					el.vars.this_con.find(el.options.selector_con).slideDown(400, function(){
						if(el.options.auto_scroll) admin.targetScroll(el.vars.this_con, false);
					});
				}else{
					el.vars.this_con.addClass(el.options.class_active);
					if(el.options.auto_scroll) admin.targetScroll(el.vars.this_con, false);
				}

				if(el.options.aria_flag){
					if(el.options.toggle_type =="tab"){
						el.vars.this_btn.parents(el.options.selector).addClass(el.options.class_active);
						el.vars.this_btn.attr('aria-selected',true).attr('title','선택됨');
						if(el.options.selector_con=="#href") $(el.vars.this_btn.attr('href')).attr('aria-expanded',true);
					}

					if(el.options.toggle_type =="toggle"){
						el.vars.this_btn.attr('aria-expanded',true);
					}
				}

				//상태텍스트 설정
				if(el.options.txt_state){
					if(el.vars.this_btn.attr('title')) el.vars.this_btn.attr('title',el.vars.this_btn.attr('title').replace(el.options.txt_state_open,el.options.txt_state_close));
					if(el.vars.this_btn.attr('aria-label')) el.vars.this_btn.attr('aria-label',el.vars.this_btn.attr('aria-label').replace(el.options.txt_state_open,el.options.txt_state_close));
					el.vars.this_btn.html(el.vars.this_btn.html().replace(el.options.txt_state_open,el.options.txt_state_close));
				}

				if(el.options.btn_flag) el.vars.this_btn.addClass(el.options.class_active);

				//콜백함수(load)
				if (typeof el.options.callback_load === 'function'){
					//el.options.callback_load.call(el);
					el.options.callback_load.call(el,el.vars);
				};

				//컨텐츠 내부 닫기기능
				if (!!el.options.selector_close){
					el.vars.this_close = el.vars.this_con.find(el.options.selector_close);
					el.vars.this_close.on('click.togglecon', function(e){
						methods.conHide();
						$(el.vars.this_btn).focus();
					});
				}

				//외부영역 클릭시 닫기
				if(el.options.doc_event){
					$(document).on('click.togglecon', function(e){
						if(!$(e.target).closest(el.vars.this_btn).length) {
							methods.conHide();
						}
					});
				}
			};

			/* ---------------------------------------------------------------------------
				togglecon.conHide : 컨텐츠닫기
			--------------------------------------------------------------------------- */
			methods.conHide = function(){
				if(el.options.load_animation){
					$(el.vars.this_con).removeClass(el.options.class_active);
					el.vars.this_con.find(el.options.selector_con).slideUp(400, function(){

					});
				}else{
					$(el.vars.this_con).removeClass(el.options.class_active);
				}

				if(el.options.btn_flag) el.vars.this_btn.removeClass(el.options.class_active);

				if (typeof el.options.callback_after === 'function'){
					el.options.callback_after.call(el,el.vars);
				}

				if(el.options.txt_state){
					if(el.vars.this_btn.attr('title')) el.vars.this_btn.attr('title',el.vars.this_btn.attr('title').replace(el.options.txt_state_close,el.options.txt_state_open));
					if(el.vars.this_btn.attr('aria-label')) el.vars.this_btn.attr('aria-label',el.vars.this_btn.attr('aria-label').replace(el.options.txt_state_close,el.options.txt_state_open));
					el.vars.this_btn.html(el.vars.this_btn.html().replace(el.options.txt_state_close,el.options.txt_state_open));
				}

				if(el.options.toggle_type =="toggle"){
					el.vars.this_btn.attr('aria-expanded',false);
				}
			};

			/* ---------------------------------------------------------------------------
				외부호출 : 닫기
			--------------------------------------------------------------------------- */
			el.outputClose = function(){
				if(el.options.toggle_type=="toggle"){
					el.vars.this_btn = $(el.options.selector+' '+el.options.selector_btn);
					el.vars.this_con = $(el.options.selector);
					methods.conHide();
				}
			};

			/* ---------------------------------------------------------------------------
				외부호출 : 열기
			--------------------------------------------------------------------------- */
			el.outputOpen = function(etarget){
				if(el.options.toggle_type=="toggle"){
					el.vars.this_btn = $(el.options.selector+' '+el.options.selector_btn);
					el.vars.this_con = $(el.options.selector);
					methods.conShow();
				}
			};

			methods.init();

			togglecons = $(document).data(pluginName);

			if (!togglecons){
				togglecons = $([]);
			}

			if ($.inArray(el, togglecons) === -1){
				togglecons.push(el);
			}
			$(document).data(pluginName, togglecons);
			el.data(pluginName, el);
			return el;
		}
	});
})(window, jQuery);